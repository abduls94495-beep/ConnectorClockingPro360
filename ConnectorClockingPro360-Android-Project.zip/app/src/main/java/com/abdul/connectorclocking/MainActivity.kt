package com.abdul.connectorclocking

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.net.Uri
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.atan2

class MainActivity : Activity() {
    private lateinit var imageView: MeasurementView
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var mode: Spinner
    private lateinit var tolerance: EditText
    private val history = mutableListOf<String>()
    private var currentAngle: Double? = null
    private val pickImage = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { loadImage(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(245, 248, 252))
        }
        val title = TextView(this).apply {
            text = "CONNECTOR CLOCKING PRO 360"
            textSize = 20f; setTextColor(Color.rgb(15, 55, 100)); gravity = Gravity.CENTER
            setPadding(4, 12, 4, 12)
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text = "MIL-DTL-38999 • Photo-assisted measurement"
            textSize = 13f; gravity = Gravity.CENTER; setTextColor(Color.DKGRAY)
        }
        root.addView(subtitle)

        mode = Spinner(this)
        mode.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Manual mode", "Assisted mode"))
        root.addView(mode)

        val choose = Button(this).apply {
            text = "Select connector photo"
            setOnClickListener { pickImage.launch("image/*") }
        }
        root.addView(choose)

        status = TextView(this).apply {
            text = "Choose a clear, front-facing connector photo. Then mark the centre, zero reference and backshell reference."
            textSize = 13f; setTextColor(Color.DKGRAY); setPadding(4, 10, 4, 10)
        }
        root.addView(status)

        imageView = MeasurementView()
        root.addView(imageView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val instructions = TextView(this).apply {
            text = "Tap 1: connector centre   •   Tap 2: 0° datum   •   Tap 3: backshell reference"
            textSize = 12f; setTextColor(Color.rgb(40, 65, 90)); setPadding(2, 8, 2, 8)
        }
        root.addView(instructions)

        val tolRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        tolRow.addView(TextView(this).apply { text = "Tolerance ±°: "; textSize = 14f })
        tolerance = EditText(this).apply {
            setText("5"); inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
        }
        tolRow.addView(tolerance, LinearLayout.LayoutParams(100, 48))
        root.addView(tolRow)

        val calc = Button(this).apply {
            text = "Calculate clocking angle"
            setOnClickListener { calculate() }
        }
        root.addView(calc)
        result = TextView(this).apply {
            text = "Clocking angle: —"
            textSize = 22f; gravity = Gravity.CENTER; setTextColor(Color.rgb(20, 110, 65))
            setPadding(4, 12, 4, 12)
        }
        root.addView(result)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(Button(this).apply {
            text = "Reset"
            setOnClickListener { imageView.resetPoints(); result.text = "Clocking angle: —"; currentAngle = null }
        }, LinearLayout.LayoutParams(0, 48, 1f))
        actions.addView(Button(this).apply {
            text = "Save report"
            setOnClickListener { saveReport() }
        }, LinearLayout.LayoutParams(0, 48, 1f))
        actions.addView(Button(this).apply {
            text = "History"
            setOnClickListener { showHistory() }
        }, LinearLayout.LayoutParams(0, 48, 1f))
        root.addView(actions)
        setContentView(root)
    }

    private fun loadImage(uri: Uri) {
        try {
            contentResolver.openInputStream(uri).use { stream ->
                val bitmap = BitmapFactory.decodeStream(stream)
                if (bitmap != null) {
                    imageView.setBitmap(bitmap)
                    status.text = if (mode.selectedItemPosition == 0)
                        "Manual: tap centre, datum (0°), then backshell reference."
                    else
                        "Assisted: image loaded. Confirm the three reference points by tapping them; angle is calculated from the marked references."
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open image", Toast.LENGTH_SHORT).show()
        }
    }

    private fun calculate() {
        val angle = imageView.calculateAngle()
        if (angle == null) {
            Toast.makeText(this, "Select a photo and mark all 3 points first", Toast.LENGTH_LONG).show()
            return
        }
        currentAngle = angle
        val tol = tolerance.text.toString().toDoubleOrNull() ?: 5.0
        val pass = angle <= tol || (360.0 - angle) <= tol || kotlin.math.abs(angle - 180.0) <= tol
        result.text = String.format(Locale.US, "Clocking angle: %.1f°  %s", angle, if (pass) "• within ±${tol}° check" else "")
        status.text = "Measured from the marked datum to backshell reference. Verify against the approved drawing/work instruction."
    }

    private fun saveReport() {
        val a = currentAngle
        if (a == null) {
            Toast.makeText(this, "Calculate an angle first", Toast.LENGTH_SHORT).show()
            return
        }
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        history.add("$stamp,${String.format(Locale.US, "%.1f", a)}")
        Toast.makeText(this, "Report saved in this app session", Toast.LENGTH_SHORT).show()
    }

    private fun showHistory() {
        val text = if (history.isEmpty()) "No reports saved in this session."
                   else "Date & time,Angle (degrees)\n" + history.joinToString("\n")
        AlertDialog.Builder(this).setTitle("Measurement history").setMessage(text)
            .setPositiveButton("OK", null).show()
    }

    inner class MeasurementView : View(this) {
        private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val pointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.RED; style = Paint.Style.FILL }
        private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GREEN; strokeWidth = 4f }
        private var bitmap: Bitmap? = null
        private val points = mutableListOf<Pair<Float, Float>>()

        fun setBitmap(b: Bitmap) { bitmap = b; points.clear(); invalidate() }
        fun resetPoints() { points.clear(); invalidate() }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.rgb(225, 232, 240))
            val b = bitmap ?: run {
                val p = Paint().apply { color = Color.DKGRAY; textSize = 35f; textAlign = Paint.Align.CENTER }
                canvas.drawText("Select a connector photo", width / 2f, height / 2f, p)
                return
            }
            val scale = minOf(width.toFloat() / b.width, height.toFloat() / b.height)
            val left = (width - b.width * scale) / 2f
            val top = (height - b.height * scale) / 2f
            val dst = android.graphics.RectF(left, top, left + b.width * scale, top + b.height * scale)
            canvas.drawBitmap(b, null, dst, bitmapPaint)
            if (points.size >= 2) canvas.drawLine(points[0].first, points[0].second, points[1].first, points[1].second, linePaint)
            if (points.size >= 3) canvas.drawLine(points[0].first, points[0].second, points[2].first, points[2].second, Paint(linePaint).apply { color = Color.RED })
            points.forEachIndexed { i, pt ->
                canvas.drawCircle(pt.first, pt.second, 11f, pointPaint)
                val label = Paint().apply { color = Color.WHITE; textSize = 28f; isFakeBoldText = true }
                canvas.drawText("${i + 1}", pt.first + 12f, pt.second - 12f, label)
            }
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action == MotionEvent.ACTION_UP) {
                if (bitmap == null) return true
                if (points.size == 3) points.clear()
                points.add(Pair(event.x, event.y))
                invalidate()
                status.text = when(points.size) {
                    1 -> "Centre marked. Tap the 0° datum/notch reference."
                    2 -> "Datum marked. Tap the backshell reference point."
                    else -> "Three points marked. Press Calculate."
                }
                return true
            }
            return true
        }

        fun calculateAngle(): Double? {
            if (points.size != 3) return null
            val c = points[0]; val datum = points[1]; val ref = points[2]
            val a1 = Math.toDegrees(atan2((datum.second-c.second).toDouble(), (datum.first-c.first).toDouble()))
            val a2 = Math.toDegrees(atan2((ref.second-c.second).toDouble(), (ref.first-c.first).toDouble()))
            var diff = (a2 - a1 + 360.0) % 360.0
            // Image coordinates have Y downward; convert to conventional clockwise-positive angle.
            diff = (360.0 - diff) % 360.0
            return diff
        }
    }
}
