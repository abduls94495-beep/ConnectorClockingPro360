# Connector Clocking Pro 360

A starter Android project for photo-based connector clocking measurements.

## Features in this starter build
- Select a connector image from the phone gallery.
- Manual three-point measurement: centre, 0-degree datum, backshell reference.
- Assisted mode is currently a guided/photo-assisted workflow, **not automatic AI detection**.
- Angle output from 0 to 360 degrees.
- Adjustable tolerance entry.
- In-session measurement history.

## Important measurement note
This app calculates the angle between user-marked points in the displayed image. It does not calibrate camera perspective, identify connector features automatically, or replace approved engineering inspection equipment / drawings. Use a perpendicular photo and verify every result against the applicable drawing and work instruction before production use.

## Build APK for free using GitHub Actions
1. Create a free GitHub account and a new repository named `ConnectorClockingPro360`.
2. Upload the contents of this ZIP to the repository (not the ZIP itself).
3. Open the repository's **Actions** tab and enable workflows if prompted.
4. Select **Build Android APK** and press **Run workflow**.
5. Wait for the workflow to finish successfully.
6. Open that workflow run, scroll to **Artifacts**, and download `ConnectorClockingPro360-debug-apk`.
7. Extract the downloaded artifact ZIP. Install `app-debug.apk` on your Android phone. Android may ask you to allow installation from that source.

## Local build
Requires Android Studio, JDK 17, and Gradle 8.9:
`gradle :app:assembleDebug`

The APK output is:
`app/build/outputs/apk/debug/app-debug.apk`
